# MatchPoint Blueprint response experiment

Extract this ZIP, install requirements.txt with Python 3.12, and run python agent.py.
The default Weights 2 strategy can switch to the included GPU-trained CPU lookup table after observing preflop betting.
