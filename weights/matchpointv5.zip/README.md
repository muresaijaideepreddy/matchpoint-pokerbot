# matchpointv5

Run with Python 3.12: install requirements.txt, then run python agent.py. No GPU or internet is needed to play. Weights 3 play with a per-half stop-loss; see agent.py for the switching rules and BuildProvenance.json for exact runtime hashes. experiments/blueprint_brain/README.md credits the third-party Blueprint strategy.
