# MatchPoint SizeMix

Extract the ZIP and run the following commands with Python 3.12 or later:

    python -m pip install -r requirements.txt
    python agent.py

This CPU bot includes the published MatchPoint Compact96 and CFR150k weights.
It tracks opponents' preflop open and reraise sizes. Once it has seen at
least 25 opens and 10 reraises and the specified pattern is present, it can
select the self-play policy in a spot where the release would use Compact96.
The Docker image runs on port 5008 by default and honors PORT and AGENT_TOKEN.
Its public bot name is MatchPoint and its participant field is PokerBot.

Run the organizer's build and smoke checks with `bash tools/check_build.sh`.
BuildProvenance.json records the release archive, evaluated image and file hashes.
