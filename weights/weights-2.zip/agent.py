"""Serve MatchPoint with the release-based SizeMix gate."""
import os
import uvicorn
from size_mix_router import PARTICIPANT, choose_release_action as choose_action, new_half, on_hand_end
from bot_server import create_app

AGENT_NAME = "MatchPoint"
app = create_app(globals())

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "5008")), access_log=False)
