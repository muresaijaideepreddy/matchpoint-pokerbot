# MatchPoint tournament challenger

Run with Python 3.12: install requirements.txt, then run python agent.py. No GPU or internet is needed to play. Development candidates are not tournament submissions. See BuildProvenance.json for exact runtime hashes.
