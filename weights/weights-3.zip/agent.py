"""MatchPoint: choose a trained policy using only observed betting behavior."""
import os, uvicorn
from bot_server import create_app
from matchpoint import AGENT_NAME, PARTICIPANT, on_hand_end
from size_mix_router import choose_release_action, record_preflop_raise
from experiments.blue_gpu import gate
from experiments.field_response import runtime as field

new_half=gate.new_half

def choose_action(obs,memory):
    record_preflop_raise(obs,memory)
    if obs.hand_index>=55:
        if memory.get("fr_hand")!=obs.hand_index:
            field.classify(obs,memory)
        if memory["fr_index"]>=0:
            return field.select(obs,memory,choose_release_action(obs,memory))
    if not memory["blue_gpu_latched"] and gate.detect(memory):
        memory["blue_gpu_latched"]=True
    if memory["blue_gpu_latched"]:
        return gate.policy.select(obs,memory)
    return choose_release_action(obs,memory)

app=create_app(globals())
if __name__=="__main__":uvicorn.run(app,host="0.0.0.0",port=int(os.environ.get("PORT",5008)),access_log=False)
